Première - Dernière Version

05/06/24      25/06/24				1-Déploiement-Wazuh-Phase-Test 
17/06/24      25/06/24				2-Commandes de Configurations Serveur
20/06/24      20/06/24				3-Installation-Serveur-Ubuntu-Important
20/06/24      20/06/24				4-Rapport Des Dysfonctionnements
25/06/24      25/06/24				5-Arborescence-des-Fonctionnalités-Wazuh
20/06/24      20/06/24				6-6-Déploiement Du Module FIM

// Beaucoup de descriptions sur les fonctionnalités de l'API de Wazuh en terme de gestion Server, d'indexeur et de Dashboard n'ont
   pas été faites pour seule raison que les actions possibles sont assez facilement déductibles et que cela implique beaucoup de notions 
   que je suis loin de maîtriser
   
   Même chose pour les modules, toute cette documentation ne doit être qu'une aide, pas un guide, inutile de chercher quelque chose qui 
   n'est pas implicitement présent dans les fichiers 
   
   Bon courage